let menu = document.querySelector('#menu-bar');
let navbar = document.querySelector('.navbar');

menu.onclick = () =>{
    menu.classList.toggle('fa-times');
    navbar.classList.toggle('active');
}

window.onscroll = () =>{
    menu.classList.remove('fa-times');
    navbar.classList.remove('active');
}



let form = document.getElementById("subscribeform")

function validateName(name){
    
    return(
        name.length >= 2 && name.length <= 20
    )
}

let emailErrorMessage = [
    "Email must contain @",
    "Email must contain .(yahoo.com,gmail.com)"
]

function validateEmail(email){
   
    let split = email.split("@")

    if(split.length == 1){
        return 0 
    }

    let checkDot = split[split.length - 1]
 
   
    let checkDotSplit = checkDot.split(".")
    if(checkDotSplit.length == 1){
        return 1 
    }
    return -1
}

function validatePhoneNumber(phone){
    return(
        phone.length >=10
    )
}


function validateCountry(country){
    if(country.selectedIndex == 0){
        return false
    }
    return true
}

let error = document.getElementById("error");
function showError(message){
    
    error.style.display = 'block'
    error.innerHTML = message
}

function clearError(){
    error.style.display = "none"
}

function formSubmit(){
    let name = document.getElementById("name");
    if(!validateName(name.value)){
        showError("Name length must be in range 2 - 16")
        return
    }
    let email = document.getElementById("email")
    let checkEmail = validateEmail(email.value)
    if(checkEmail != -1){
        showError(emailErrorMessage[checkEmail])
        return
    }
    
    let phone = document.getElementById("phone")
    if(!validatePhoneNumber(phone.value)){
        showError("Please enter a valid digit phone number")
        return
    }
    

    let countries = document.getElementById("country")
    if(!validateCountry(countries)){
        showError("Please select a country")
        return
    }
    let country = countries.options[countries.selectedIndex].value

    let checkBox = document.getElementById("agree")
    if(!checkBox.checked){
        showError("Please agree to terms and condition")
        return
    }

    clearError()
    alert("Form succesfully submitted")
    console.log(name.value)
    console.log(email.value)
    console.log(phone.value)
    console.log(country)
    console.log(checkBox.value)

    document.getElementById("subscribeform").reset()
}

form.addEventListener("submit", (e)=>{
    e.preventDefault()
    formSubmit()
})

